import os
from dotenv import load_dotenv
from langchain_huggingface import HuggingFaceEndpoint
from langchain.text_splitter import CharacterTextSplitter
from langchain.prompts import PromptTemplate
import spacy
import yaml

class JobApplicationAgent:
    def __init__(self):
        load_dotenv()
        self.llm = HuggingFaceEndpoint(
            repo_id="google/flan-t5-large",  # Changed to a very small model that may support text-generation
            huggingfacehub_api_token=os.getenv("HUGGINGFACEHUB_API_TOKEN")
        )
        self.nlp = spacy.load('en_core_web_sm')

    def read_job_description(self, file_path):
        """Read and process the job description from a text file."""
        with open(file_path, 'r') as file:
            return file.read()

    def extract_requirements(self, job_description):
        """Extract key requirements from the job description using SpaCy."""
        doc = self.nlp(job_description)
        requirements = []
        for sent in doc.sents:
            if any(keyword in sent.text.lower() for keyword in 
                ['required', 'requirements', 'qualifications', 'must have', 'skills']):
                requirements.append(sent.text.strip())
        return requirements

    def generate_cover_letter(self, job_description, requirements, user_profile):
        """Generate a tailored cover letter based on the JD and user profile."""
        cover_letter_template = """
        Dear Hiring Manager,

        Based on the following job requirements and my profile, write a professional and engaging cover letter:
        
        Job Description: {job_description}
        
        Key Requirements:
        {requirements}
        
        My Profile:
        {user_profile}
        
        The cover letter should highlight relevant experience and skills while maintaining a professional tone.
        """
        prompt = PromptTemplate(
            input_variables=['job_description', 'requirements', 'user_profile'],
            template=cover_letter_template
        )
        runnable = prompt | self.llm
        return runnable.invoke({
            "job_description": job_description,
            "requirements": "\n".join(requirements),
            "user_profile": user_profile
        })

    def generate_video_script(self, cover_letter, user_profile):
        """Generate a one-minute video script introduction."""
        script_template = """
        Create a engaging one-minute video script where I introduce myself based on:
        
        Cover Letter Highlights: {cover_letter}
        My Profile: {user_profile}
        
        The script should be natural, professional, and highlight key strengths while being time-conscious (one minute).
        """
        prompt = PromptTemplate(
            input_variables=['cover_letter', 'user_profile'],
            template=script_template
        )
        runnable = prompt | self.llm
        return runnable.invoke({
            "cover_letter": cover_letter,
            "user_profile": user_profile
        })

    def save_outputs(self, outputs, output_dir='outputs'):
        """Save all generated content to files."""
        os.makedirs(output_dir, exist_ok=True)
        with open(f'{output_dir}/application_package.yaml', 'w') as f:
            yaml.dump(outputs, f)
        for key, content in outputs.items():
            with open(f'{output_dir}/{key}.txt', 'w') as f:
                f.write(content)
